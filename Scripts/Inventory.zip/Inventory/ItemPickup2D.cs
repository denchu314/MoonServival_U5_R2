using UnityEngine;

public class ItemPickup2D : MonoBehaviour
{
    [SerializeField] public string itemName;       // アイテム名
    [SerializeField] public Sprite itemIcon;       // インベントリ上で表示するアイコン
    [SerializeField] public GameObject itemPrefab; // 地面に置く時に生成する 2D用 Prefab

    public string ItemName => itemName;
    public Sprite ItemIcon => itemIcon;
    public GameObject ItemPrefab => itemPrefab;
}
