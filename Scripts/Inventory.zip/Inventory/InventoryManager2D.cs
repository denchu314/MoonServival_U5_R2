using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class ItemData
{
    public string itemName;        // アイテム名
    public Sprite itemIcon;        // インベントリ表示用アイコン
    public GameObject itemPrefab;  // 設置時に生成するPrefab（2D/3D問わず）

    // 数量や耐久度などが必要であれば、ここにフィールドを追加
    // public int quantity;
    // public float durability;
    
    // 必要であればコンストラクタも用意
    public ItemData(string name, Sprite icon, GameObject prefab)
    {
        itemName = name;
        itemIcon = icon;
        itemPrefab = prefab;
    }
    
    // 引数無しのデフォルトコンストラクタが必要なら省略可 or 下記のように用意
    public ItemData() {}
}

public class InventoryManager2D : MonoBehaviour
{
    public static InventoryManager2D Instance;

    [SerializeField] private int slotCount = 10;
    [SerializeField] private InventorySlot[] slots;
    [SerializeField] private Image[] slotImages;   // UI上の10枠分の Image コンポーネント
    [SerializeField] private Color selectedColor = Color.yellow;
    [SerializeField] private Color normalColor = Color.white;

    private int selectedIndex = 0; // 選択中のスロット

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }

        slots = new InventorySlot[slotCount];
        for (int i = 0; i < slotCount; i++)
        {
          slots[i] = new InventorySlot();
        }
    }

    private void Start()
    {
        UpdateUI();
    }

    private void Update()
    {
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll > 0f)
        {
            selectedIndex--;
            if (selectedIndex < 0) selectedIndex = slotCount - 1;
            UpdateUI();
        }
        else if (scroll < 0f)
        {
            selectedIndex++;
            if (selectedIndex >= slotCount) selectedIndex = 0;
            UpdateUI();
        }

        // for(int j = 0; j < slotCount; j++){
        //             Debug.Log("Item:"+ slots[j].item + ", Count:" + j + ", Null?:" + (slots[j].item == null));
        // }
    }

    /// <summary>
    /// アイテムをインベントリに追加する
    /// </summary>
    // public bool AddItem(ItemPickup2D newItem)
    // {

    //     for (int i = 0; i < slotCount; i++)
    //     {
    //         //Debug.Log("slotCount:"+ slotCount);
    //         if (slots[i].item == null)
    //         {
    //             slots[i].item = newItem;
    //             // for(int j = 0; j < slotCount; j++){
    //             //     Debug.Log("Item:"+ slots[j].item + ", Count:" + j + ", Null?:" + (slots[j].item == null));
    //             // }
    //             UpdateUI();
    //             return true;
    //         }
    //     }
    //     Debug.Log("インベントリが満杯です");
    //     return false;
    // }

    // public bool AddItem(ItemPickup2D newItemPickup)
    // {
    //   for (int i = 0; i < slotCount; i++)
    //     {
    //         if (slots[i].item == null)
    //         {
    //             // 必要データだけをコピーした専用クラスや構造体にする。例:

    //             ItemPickup2D copiedData = newItemPickup;
    //             //var copiedData = new ItemData();
    //             //copiedData.itemName = newItemPickup.ItemName;
    //             //copiedData.itemIcon = newItemPickup.ItemIcon;
    //             //copiedData.itemPrefab = newItemPickup.ItemPrefab;
    //             //slots[i].item = copiedData; // ここはGameObjectではなくData
    //             //slots[i].item.itemIcon  = copiedData.itemIcon; // ここはGameObjectではなくData
    //             //slots[i].item.itemPrefab = copiedData.itemPrefab; // ここはGameObjectではなくData
                
    //             UpdateUI();
    //             return true;
    //         }
    //     }
    //     return false;
    // }

    public bool AddItem(ItemPickup2D newItemPickup)
    {
      for (int i = 0; i < slotCount; i++)
        {
            if (slots[i].item == null)
            {
            // ItemDataを生成
            var copiedData = new ItemData();
            copiedData.itemName   = newItemPickup.ItemName;
            copiedData.itemIcon   = newItemPickup.ItemIcon;
            copiedData.itemPrefab = newItemPickup.ItemPrefab;

            // ここでスロットにコピー
            slots[i].item = copiedData;
                UpdateUI();
                return true;
            }
        }
        return false;
    }

// public bool AddItem(ItemPickup2D newItemPickup)
// {
//     for (int i = 0; i < slotCount; i++)
//     {
//         // itemData が null → まだアイテムデータが入っていない
//         if (slots[i].itemData == null)
//         {
//             // ItemDataを生成
//             var copiedData = new ItemData();
//             copiedData.itemName   = newItemPickup.ItemName;
//             copiedData.itemIcon   = newItemPickup.ItemIcon;
//             copiedData.itemPrefab = newItemPickup.ItemPrefab;

//             // ここでスロットにコピー
//             slots[i].itemData = copiedData;

//             UpdateUI();
//             return true;
//         }
//     }
//     return false;
// }


    /// <summary>
    /// 選択中のスロットのアイテムを取得
    /// </summary>
    public ItemPickup2D GetSelectedItem()
    {
        return slots[selectedIndex].item;
    }

    /// <summary>
    /// 選択中のスロットのアイテムを削除
    /// </summary>
    public void RemoveSelectedItem()
    {
        slots[selectedIndex].item = null;
        UpdateUI();
    }

    /// <summary>
    /// スロットUIの更新
    /// </summary>
    private void UpdateUI()
    {
        for (int i = 0; i < slotCount; i++)
        {
            if (slotImages != null && slotImages.Length > i && slotImages[i] != null)
            {
                if (slots[i].item != null)
                {
                    slotImages[i].sprite = slots[i].item.ItemIcon;
                    slotImages[i].color = Color.white;
                }
                else
                {
                    slotImages[i].sprite = null;
                    slotImages[i].color = Color.white;
                    //slotImages[i].color = new Color(1, 1, 1, 0); // 透明にして非表示に
                }

                // 枠の色を変える
                var parentImage = slotImages[i].transform.parent.GetComponent<Image>();
                if (parentImage != null)
                {
                    parentImage.color = (i == selectedIndex) ? selectedColor : normalColor;
                }
            }
        }
    }
}
