using UnityEngine;

public class ItemPickupController2D : MonoBehaviour
{
    [SerializeField] private Camera mainCamera;  // メインカメラ (Orthographic推奨)

    void Update()
    {
        // 右クリックでアイテム拾う
        if (Input.GetMouseButtonDown(1))
        {
            // マウス位置→ワールド座標
            Vector2 mousePos = mainCamera.ScreenToWorldPoint(Input.mousePosition);

            // 2DのRaycast (Rayの向きはゼロベクター。点だけ判定)
            RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero, 0f);
            if (hit.collider != null)
            {
                ItemPickup2D itemPickup = hit.collider.GetComponent<ItemPickup2D>();
                if (itemPickup != null)
                {
                    // インベントリに追加
                    bool added = InventoryManager2D.Instance.AddItem(itemPickup);
                    if (added)
                    {
                        //Destroy(hit.collider.gameObject); // ゲームオブジェクトを消す
                    }
                }
            }
        }

        // 左クリックでアイテムを設置
        if (Input.GetMouseButtonDown(0))
        {
            // 選択中のアイテムを取得
            ItemPickup2D selectedItem = InventoryManager2D.Instance.GetSelectedItem();
            if (selectedItem != null)
            {
                // マウス位置→ワールド座標
                Vector2 mousePos = mainCamera.ScreenToWorldPoint(Input.mousePosition);

                // 地面(グリッド)に設置する位置をスナップ
                Vector2 placePosition = SnapToGrid(mousePos);

                // 2DアイテムのPrefabをInstantiate
                Instantiate(selectedItem.ItemPrefab, placePosition, Quaternion.identity);

                // インベントリから削除
                InventoryManager2D.Instance.RemoveSelectedItem();
            }
        }
    }

    /// <summary>
    /// 2Dグリッドにスナップする例 (1マス単位)
    /// </summary>
    private Vector2 SnapToGrid(Vector2 originalPos)
    {
        float gridSize = 1f; // 1マスの大きさ
        float x = Mathf.Round(originalPos.x / gridSize) * gridSize;
        float y = Mathf.Round(originalPos.y / gridSize) * gridSize;
        return new Vector2(x, y);
    }
}
