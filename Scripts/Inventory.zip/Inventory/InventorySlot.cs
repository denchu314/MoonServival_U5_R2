[System.Serializable]
public class InventorySlot
{
    public ItemPickup2D item; // どのアイテムを保持しているか

    // 今後、数量や耐久度などを追加するならここに書く
}
